package com.fishman.oj_backend_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OjBackendMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
