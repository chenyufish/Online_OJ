package com.fishman.oj_backend_microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OjBackendMicroserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OjBackendMicroserviceApplication.class, args);
    }

}
